//
//  user.swift
//  BankProject
//
//  Created by Manpreet on 2020-10-29.
//

import Foundation

class user
{
    var name : String
    var email : String
    var accountType : String
    var accountNumber : Int
    var balance : Double
    
    init(name : String , email : String , accountType : String ,accountNumber : Int ,balance : Double) {
        self.name = name
        self.email = email
        self.accountType = accountType
        self.accountNumber = accountNumber
        self.balance = balance
    }
   
    func printUserDetail() -> String
    {
        let detail = self.name + "," + self.email + "," + self.accountType + "," + String(self.accountNumber) + "," + String(self.balance) + "\n"
        return detail
    }
}
