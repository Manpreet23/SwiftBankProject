//
//  main.swift
//  BankProject
//
//  Created by Manpreet on 2020-10-29.
//

import Foundation

var obj = [user]()

let directoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
let fileURL = URL(fileURLWithPath: "bankinfo", relativeTo:directoryURL).appendingPathExtension("txt")

print("\t\tWelcome to Bank System \n ")
print("\tChoose options to proceed in system \n")
while(true)
{
   print("\t1 for Create user account")
    print("\t2 for Login to view information ")
    print("\t3 for Transactions ")
    print("\t0 for exit ")
    
    let startChoice = Int(readLine()!)!
    
    switch startChoice {
    case 1:
        obj.removeAll()
        readingFromFile()
        fillData()
        savingData()
        
        break
    case 2:
        readingFromFile()
        print("Enter account number to show details")
        let accountNumber = Int(readLine()!)!
       let result = searchByAccount(accountNumber : accountNumber)
        
        
        if result == nil {
            print("The account doesn't exist")
        }
        else{
            print("Name:\(result!.name)\navailable balance:\( result!.balance) \nemail:\( result!.email) \naccount type:\( result!.accountType)")
        }
        
        obj.removeAll()
        break
        
    case 3:
    chooseTransaction()
    break
    case 0:
        break
    default:
        print("Wrong input")
        break
    }
   
    if startChoice==0 {
        break
    }
}

var name : String
var email : String
var accountType : String
var accountNumber : Int
var balance : Double


func fillData()
{
    print("Enter user name")
    let name = readLine()!
    
    print("Enter user email")
    let email = readLine()!
    
    print("Enter user account type")
    let accountType = readLine()!
    
    print("Enter user account number")
    let accountNumber = Int(readLine()!)!
    
    print("Enter user balance")
    let balance = Double(readLine()!)!
    
    obj.append(user(name: name, email: email, accountType: accountType, accountNumber: accountNumber, balance: balance))


}

func readingFromFile(){
do {
 // Get the saved data
 let savedData = try Data(contentsOf: fileURL)
 // Convert the data back into a string
    if String(data: savedData, encoding: .utf8) != nil {
    //print(savedString)
    let data = String(decoding: savedData, as: UTF8.self)
    let lines = data.split(whereSeparator: \.isNewline)
    for line in lines{
        //split each line into words which are fields
        let fields = line.components(separatedBy: ",")
        //create an object of user assuming the seprated words are the inputs
        let info = user(name: fields[0], email: fields[1], accountType: fields[2], accountNumber: Int(fields[3])!, balance: Double(fields[4])!)
        obj.append(info)//add the object product to the array of products
    }
 }
} catch {
 // Catch any errors
 print("Unable to read the file")
}
}
func savingData(){
    print("count",obj.count)
   
    //merging all lines form the array in one string
    var myString:String = ""
    for pr in obj{
        
        myString += pr.printUserDetail()
    }
    //convert from string to data
    let data = myString.data(using: .utf8)
    do {
        //write the data into the file
        try data?.write(to: fileURL)
        print("Operation successfully done\n \n ")
     print("File saved: \(fileURL.absoluteURL)")
    } catch {
     // Catch any errors
     print(error.localizedDescription)
    }
    
 obj.removeAll()
}


//function to search account number which return whole object corresponding to account number
func searchByAccount(accountNumber:Int) ->user?
{
    for user in obj {
        if user.accountNumber == accountNumber{
            return user
        }
    }
    return nil
}

func chooseTransaction()
{
    print("\tChoose option to perform required operation\n")
    print("a for display balance")
    print("b for deposit money")
    print("c for withdraw money")
    print("d for pay utility bills")
    print("e for transfer money")
    
    
    let transacationChoice = readLine()!
    
    switch transacationChoice {
    case "a":
    
       readingFromFile()
        print("Enter account number to show balance")
        let accountNumber = Int(readLine()!)!
       let result = searchByAccount(accountNumber : accountNumber)
        
        
        if result == nil {
            print("The account doesn't exist")
        }
        else{
            print("Available balance is: \( result!.balance) ")
        }
        break
    case "b":
       readingFromFile()
        print("Enter account number ")
        let accountNumber = Int(readLine()!)!
        
        print("Enter amount to deposit")
        let amount = Double(readLine()!)!
        
       let result = searchByAccount(accountNumber : accountNumber)
        
        
        if result == nil {
            print("The account doesn't exist")
        }
        else{
           // print("Available balance is: \( result!.balance + amount) ")
            
            updateAmount(accountNumber: accountNumber, balance: result!.balance + amount)
           

        }
        break
    case "c":
        
        readingFromFile()
         print("Enter account number ")
         let accountNumber = Int(readLine()!)!
         
         print("Enter amount to withdraw")
         let amount = Double(readLine()!)!
         
        let result = searchByAccount(accountNumber : accountNumber)
         
         
         if result == nil {
             print("The account doesn't exist")
         }
         else{
            // print("Available balance is: \( result!.balance + amount) ")
             
             updateAmount(accountNumber: accountNumber, balance: result!.balance - amount)
            

         }
     
        break
    case "d":
        
        readingFromFile()
         print("Enter account number ")
         let accountNumber = Int(readLine()!)!
         
         print("Enter amount to pay utility bills")
         let amount = Double(readLine()!)!
         
        let result = searchByAccount(accountNumber : accountNumber)
         
         
         if result == nil {
             print("The account doesn't exist")
         }
         else{
            // print("Available balance is: \( result!.balance + amount) ")
             
             updateAmount(accountNumber: accountNumber, balance: result!.balance - amount)
           //  savingData()
         }
        break
    case "e":
        
        readingFromFile()
         print("Enter account number from which you want to transfer ")
         let accountFromNumber = Int(readLine()!)!
         
        print("Enter account number to which you want to transfer ")
        let accountToNumber = Int(readLine()!)!
        
        print("Enter amount to transfer")
         let amount = Double(readLine()!)!
         
        let result = searchByAccount(accountNumber : accountFromNumber)
        let result1 = searchByAccount(accountNumber : accountToNumber)
         
         if result == nil {
             print("The account doesn't exist")
         }
        if result1 == nil {
            print("The account doesn't exist")
        }
         else{
            // print("Available balance is: \( result!.balance + amount) ")
             
            transferAmount(accountFromNumber: accountFromNumber, balanceFrom: result!.balance - amount,accountToNumber: accountToNumber,balanceTo: result1!.balance + amount)
         
         }
        break
        
    default:
        print("Wrong input")
        break
    }
}
func updateAmount(accountNumber : Int , balance : Double)
{
    
    
    
    var val = searchByAccount(accountNumber : accountNumber)
    val?.balance = balance
    
    savingData()
}
func transferAmount(accountFromNumber : Int , balanceFrom : Double,accountToNumber : Int , balanceTo : Double)
{
 
    var val1 = searchByAccount(accountNumber : accountFromNumber)
    
    var val2 = searchByAccount(accountNumber : accountToNumber)

   
    val1?.balance = balanceFrom

    val2?.balance = balanceTo

    savingData()
}
